#include <iostream>

using namespace std;

void menu()
{
    cout<<"Press 1 for Enter  the User name\n"<<"Press 2 for Enter  the Last donate\n"<<"Press 3 for Enter  the donate blood\n";
    cout<<"Press 4 for Enter  the Blood group \n"<<"Press 5 for Enter  the Take Blood\n";}

int main()
{
    menu();
}

